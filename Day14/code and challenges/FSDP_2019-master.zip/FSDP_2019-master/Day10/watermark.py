# -*- coding: utf-8 -*-
"""
Created on Sat Jun 15 00:24:18 2019

@author: Lakshya
"""
from PIL import Image
 
def watermark_with_transparency(input_image_path,
                                output_image_path,
                                watermark_image_path,
                                position):
    base_image = Image.open(input_image_path)
    watermark = Image.open(watermark_image_path)
    width, height = base_image.size
 
    transparent = Image.new('RGBA', (width, height), (0,0,0,0))
    transparent.paste(base_image, (0,0))
    transparent.paste(watermark, position, mask=watermark)
    transparent.show()
    transparent.save(output_image_path)
 
 
if __name__ == '__main__':
    img = 'shake.jpg'
    watermark_with_transparency(img, 'shake_watermark.jpg',
                                'logo.png', position=(30,30))
    
    /////////////////////////////////////////////////////////
    
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
 
 
def watermark_text(input_image_path,
                   output_image_path,
                   text, pos):
    photo = Image.open(input_image_path)
 
    # make the image editable
    drawing = ImageDraw.Draw(photo)
 
    black = (6, 16, 24)
    font = ImageFont.truetype("Pillow/Tests/fonts/comicbd.ttf", 80)
    drawing.text(pos, text, fill=black, font=font)
    photo.show()
    photo.save(output_image_path)
 
 
if __name__ == '__main__':
    img = 'shake.jpg'
    watermark_text(img, 'shake_watermarked.jpg',
                   text='www.mousevspython.com',
                   pos=(30, 30))