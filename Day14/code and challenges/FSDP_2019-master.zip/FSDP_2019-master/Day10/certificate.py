# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 15:48:29 2019

@author: Lakshya
"""
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw

name= input("Enter your name>")
course= input("Enter your course>")
date= input("Enter date>")
month= input("Enter month>")
company= input("Enter company>")

def main(): 
    try: 
        #Relative Path 
        #Image on which we want to paste 
        img = Image.open(r'C:\Users\Lakshya\Desktop\FSDP2019\Day10\template.jpg')  
          
        #Relative Path 
        #Image which we want to paste 
        img2 = Image.open(r'C:\Users\Lakshya\Desktop\FSDP2019\Day10\forsk.jpg')  
        img.paste(img2, (440, 360)) 
        
        img3 = Image.open(r'C:\Users\Lakshya\Desktop\FSDP2019\Day10\logo.jpg')  
        img.paste(img3, (60, 360)) 
          
        #Saved in the same relative location 
        img.save("pasted.jpg") 
        
        
          
    except IOError: 
        pass
  
if __name__ == "__main__": 
    main()

img = Image.open("pasted.jpg")
draw = ImageDraw.Draw(img)

selectFont = ImageFont.truetype("comicbd.ttf", size = 18)

draw.text( (240,170), name, (255,0,0), font=selectFont)


selectFont = ImageFont.truetype("comicbd.ttf", size = 20)

draw.text( (280,230), course, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 13)

draw.text( (222,280), date, (255,0,0), font=selectFont)


selectFont = ImageFont.truetype("comicbd.ttf", size = 13)

draw.text( (340,280), month, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 20)

draw.text( (180,310), company, (0,0,255), font=selectFont)


          
img.save( 'certi.pdf', "PDF", resolution=100.0)

