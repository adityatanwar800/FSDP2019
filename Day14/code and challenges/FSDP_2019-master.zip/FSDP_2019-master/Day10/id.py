from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw

school= input("Enter school name>")
name= input("Enter your name>")
gender= input("Enter gender>")
grade= input("Enter your class>")
house= input("Enter your house>")
date= input("Enter your DOB in dd-mm-yyyy>")
address= input("Enter your address>")
image= input("Enter your image name in .jpg format>")

def main(): 
    try: 
        #Relative Path 
        #Image on which we want to paste 
        img = Image.open(r'C:\Users\Lakshya\Desktop\FSDP2019\Day10\id.jpg')  
          
        #Relative Path 
        #Image which we want to paste 
        img2 = Image.open(r'C:\Users\Lakshya\Desktop\FSDP2019\Day10\image')  
        img.paste(img2, (300, 83)) 
        
        
          
        #Saved in the same relative location 
        img.save("pasted.jpg") 
        
        
          
    except IOError: 
        pass
  
if __name__ == "__main__": 
    main()

img = Image.open("pasted.jpg")
draw = ImageDraw.Draw(img)

selectFont = ImageFont.truetype("comicbd.ttf", size = 28)

draw.text( (12,4), school, (0,0,255), font=selectFont)


selectFont = ImageFont.truetype("comicbd.ttf", size = 14)

draw.text( (130,73), name, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 14)

draw.text( (130,93), gender, (255,0,0), font=selectFont)


selectFont = ImageFont.truetype("comicbd.ttf", size = 14)

draw.text( (130,116), grade, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 14)

draw.text( (130,136), house, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 14)

draw.text( (130,157), date, (0,0,255), font=selectFont)

selectFont = ImageFont.truetype("comicbd.ttf", size = 18)

draw.text( (158,205), address, (0,0,255), font=selectFont)


          
img.save( 'st.pdf', "PDF", resolution=100.0)
