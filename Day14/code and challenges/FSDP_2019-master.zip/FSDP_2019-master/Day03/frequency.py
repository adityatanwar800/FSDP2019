# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 13:09:47 2019

@author: Lakshya
"""
string= input("Enter string=")
character_freq={}
for alpha in string:
    character_freq[alpha]=character_freq.get(alpha,0) + 1
print(character_freq)
from collections import Counter
print(dict(Counter(string)))
