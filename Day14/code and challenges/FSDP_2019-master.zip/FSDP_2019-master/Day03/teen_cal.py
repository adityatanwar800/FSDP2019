# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 15:02:16 2019

@author: Lakshya
"""
string= input("Enter string=")

import ast
teen_dict= ast.literal_eval(string)

def  fix_teen(value):
    if value in(15,16):
        return value
    else:
        return 0

sum_dict= {'sum':0}
for key, value in teen_dict.items():
    if value in range(13,19):
        teen_dict[key]= fix_teen(value)
    sum_dict['sum']+= teen_dict[key]
    
print(sum_dict)