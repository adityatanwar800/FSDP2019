l1=("Monday", "Wednesday", "Thursday", "Saturday")
print((l1[0], 'Tuesday', l1[1], l1[2], 'Friday', l1[3], 'Sunday'))