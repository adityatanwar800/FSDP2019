# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 13:06:15 2019

@author: Lakshya
"""
l1 = [12,24,35,24,88,120,155,88,120,155]
l2 = list ( set ( l1 ) ) 
print (l2)