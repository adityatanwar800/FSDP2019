# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 15:49:04 2019

@author: Lakshya
"""
n=input("Enter numbers >").split(",")
print("List>" + str(n))
n=tuple(n)
print("Tuple>" + str(n))
