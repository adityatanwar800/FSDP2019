# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 12:13:43 2019

@author: Lakshya
"""
l1 = [1,3,6,78,35,55 ]
l2= [12,24,35,24,88,120,155]

result = list ( set(l1).intersection(set(l2)) )
print (result)