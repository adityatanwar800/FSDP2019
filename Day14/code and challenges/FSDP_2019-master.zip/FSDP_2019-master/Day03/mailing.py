# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 13:26:16 2019

@author: Lakshya
"""
old_list=['lakshya', 'kushal', 'anubhav']
new_list=['lakshya', 'kushal']
diff_list=list(set(old_list).difference(new_list))
print(diff_list)