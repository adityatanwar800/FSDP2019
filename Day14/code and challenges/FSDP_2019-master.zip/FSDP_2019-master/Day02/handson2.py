# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 16:38:49 2019

@author: Lakshya
"""
def leap():
    if((year%4==0 and year%100!=0) or year%400==0):
     return True
    else:
        return False
year=int(input("Enter a year>"))
print(year)
leap()
 
   
     