# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 16:20:53 2019

@author: Lakshya
"""
our_list = list(range(1,21))
print(our_list)
print("Odd numbers: ",our_list[0::2])
print("Even numbers: ",our_list[1::2])

