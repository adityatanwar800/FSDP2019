# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 12:03:16 2019

@author: Lakshya
"""

def reverse(string):
	return (string[::-1])

string = input("Enter a string >")
print (string)
reverse(string)
