# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 11:39:52 2019

@author: Lakshya
"""
state_name = [ 'Lakshya', 'California', 'universe', 'Essketit']

vowels = list('aeiou')

final_list = []

for state in state_name:
    state_elements = list(state.lower())
    
    for element in vowels:
        while element in state_elements:
            state_elements.remove(element)
    final_list.append("".join(state_elements))

print (final_list)