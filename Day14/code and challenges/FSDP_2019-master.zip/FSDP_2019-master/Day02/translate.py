# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 12:04:57 2019

@author: Lakshya
"""
def translate(string):
    consonants = 'bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ'
    final_list = []

    for element in string:
        if element in consonants: 
            final_list.append(element+"o"+element)
        else:
            final_list.append(element)

    return "".join(final_list)
string = input("Enter a string >")
print (string)
translate(string)