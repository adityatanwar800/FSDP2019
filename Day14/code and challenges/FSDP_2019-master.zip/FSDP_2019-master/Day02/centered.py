# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 12:37:42 2019

@author: Lakshya
"""
number = input("Enter comma seperated Numbers: ").split(",")

user_list = []

for i in number:
    user_list.append(int(i))

# Sorting the list of integers
user_list.sort()

# leaving out 1 smallest and 1 largest value
final_list = user_list[1:-1]

# Calculating average
average = sum( final_list ) / len( final_list )

print ("Average is :", int( average ))