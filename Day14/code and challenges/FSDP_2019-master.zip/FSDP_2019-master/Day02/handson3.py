# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 16:55:38 2019

@author: Lakshya
"""
def isleap(year):
    return (year % 4 == 0) and (year % 100 != 0) or (year % 400 == 0)
def days_in_month(month, year):
    if(month == 'September' or month == 'April' or month == 'June' or month == 'November'):
     return 30
    elif(month == 'January' or month == 'March' or month == 'May' or month== 'July' or month == 'August' or month == 'October'):
        return 31
    elif(month == 'February' and isleap(year) == True):
        return 29
    elif(month == 'February' and isleap(year) == False):
        return 28
    
month=input("Enter a month>")
print(month)
year=int(input("Enter a year>"))
print(year)
isleap(year)
days_in_month(month, year)