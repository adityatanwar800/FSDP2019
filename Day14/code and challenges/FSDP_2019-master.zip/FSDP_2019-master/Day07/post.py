# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 17:39:28 2019

@author: Lakshya
"""


import json
import requests

Host = "https://en9fpn9ogm2bf.x.pipedream.net/post"

data = {"firstname":"dev","language":"English"}

headers = {"Content-Type":"application/json","Content-Length":len(data),"data":json.dumps(data)}

def post_method():
    response = requests.post(Host,data,headers)
    return response

print ( post_method().text )

