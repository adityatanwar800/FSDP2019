# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 15:54:30 2019

@author: Lakshya
"""
[{
    "Fname": "Rahul", "Lname": "Dev",
        "Subject": "OOPs",
        "College": "PIET",
        "Photo" : "faculty\\lakshjya.jpg",
        "Qualification": ["B.Tech", "M.Tech", "Ph.D"],
        "Contact_Details": [
            {
                "Address": "Jaipur",
                "Mobile": "7878"
            }
        ]
}
,    
{
    "Fname": "Lakshya", "Lname": "Mathur",
        "Strea": "PCM",
        "School": "SBS",
        "Photo" : "faculty\\lakshjya.jpg",
        "Contact_Details": [
            {
                "Address": "Jaipur",
                "Mobile": "7878"
            }
        ]
}
]
    