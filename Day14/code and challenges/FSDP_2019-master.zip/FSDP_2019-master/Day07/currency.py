# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 16:46:55 2019

@author: Lakshya
"""
import requests
url= "https://free.currconv.com/api/v7/convert?q=USD_INR&compact=ultra&apiKey=1a4177eb51e094db9f98"
current_USD_in_INR= requests.get(url).json()['USD_INR']
print("Equivalent INR:", round(float(input("Enter USD:"))*current_USD_in_INR,2))



