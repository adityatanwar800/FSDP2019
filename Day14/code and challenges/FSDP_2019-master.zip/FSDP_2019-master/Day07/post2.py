# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 17:46:11 2019

@author: Lakshya
"""

import json
import requests

Host = "http://httpbin.org/post"

data = {"firstname":"Lakshya","Phone_number":"94736322", "College_name":"PIET","Branch":"CS"}

headers = {"Content-Type":"application/json","Content-Length":len(data),"data":json.dumps(data)}

def post_method():
    response = requests.post(Host,data,headers)
    return response

print ( post_method().text )


def get_method():
    response = requests.get("http://13.127.155.43/api_v0.1/receiving")
    return response

print (get_method().text)