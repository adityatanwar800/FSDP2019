import json
import requests

city= input("Enter city name")
url1 = "http://api.openweathermap.org/data/2.5/weather"
url2 = "?q="+city
url3 = "&appid=e9185b28e9969fb7a300801eb026de9c"

url = url1 + url2 + url3
print (url)


response = requests.get(url)
data= response.json()


print ("Wind speed: " , data['wind']['speed'])
print ("Weather condition: " , data['weather'][0]['main'])
print ("Lon {} & Lat {}  ".format(data['coord']['lon'], data['coord']['lat']))
from datetime import datetime

Sunrise_time= datetime.fromtimestamp(data['sys']['sunrise'])
Sunset_time= datetime.fromtimestamp(data['sys']['sunset'])

print("Sunrise {} and Sunset {}".format(Sunrise_time, Sunset_time))