# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
kilo=float(input("Enter kilometres="))
litre=float(input("Enter litres"))
average=kilo/litre
print(average)
