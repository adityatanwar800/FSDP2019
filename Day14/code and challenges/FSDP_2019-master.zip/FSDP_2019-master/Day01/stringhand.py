# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 18:55:53 2019

@author: Lakshya
"""
name=input("Enter a name>")
index = name.find(' ')
print(name[index:] + " " + name[:index] )