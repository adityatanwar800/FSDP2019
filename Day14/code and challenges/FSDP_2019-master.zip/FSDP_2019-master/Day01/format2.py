# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 21:48:28 2019

@author: Lakshya
"""
name=input("Enter a string>")
print(name)
index = name.find(' ')
name.replace(' ','*')