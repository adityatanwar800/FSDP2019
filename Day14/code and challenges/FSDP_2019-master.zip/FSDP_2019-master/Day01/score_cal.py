# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 17:29:35 2019

@author: Lakshya
"""
a1= int(input("Enter score of assignment1>"))
print(a1)
a2= int(input("Enter score of assignment2>"))
print(a2)
a3= int(input("Enter score of assignment3>"))
print(a3)
e1= int(input("Enter score of exam1>"))
print(e1)
e2= int(input("Enter score of exam2>"))
print(e2)
score=((a1+a2+a3)*0.1)+((e1+e2)*0.35)
print("Weighted score=" +str(score))
      