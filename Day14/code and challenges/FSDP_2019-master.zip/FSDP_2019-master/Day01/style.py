# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 18:19:52 2019

@author: Lakshya
"""
name=input("Enter a name>")
print(name)
print("Uppercase=" +(name.upper()))
print("Lowercase=" +(name.lower()))
print("Camelcase=" +(name.title()))
