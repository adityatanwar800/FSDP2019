# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 23:52:18 2019

@author: Lakshya
"""
n=0
while(n<100):
 n=n+1
 if (n%3==0 and n%5==0):
  print("FizzBuzz")
 elif(n%3==0):
  print("Fizz")
 elif n%5==0:
  print("Buzz")
 else:
  print(n)