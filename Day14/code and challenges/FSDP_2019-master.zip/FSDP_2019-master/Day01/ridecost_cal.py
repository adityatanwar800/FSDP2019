# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 17:15:03 2019

@author: Lakshya
"""
day1=80
litre1=80
vehicle_avg=18
total_litre=day1/vehicle_avg
total_cost=day1*total_litre
print(total_cost)
