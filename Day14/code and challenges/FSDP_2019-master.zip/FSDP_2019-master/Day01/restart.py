# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 18:47:37 2019

@author: Lakshya
"""
name = 'restart'
str1 = name.replace('r','$')
str2 = str1.replace('$','r',1)

name1 = name[1:]
str1 = name1.replace('r','$')
print(name[0]+str1)