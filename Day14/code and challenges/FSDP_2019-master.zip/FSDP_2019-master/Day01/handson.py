# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 23:15:11 2019

@author: Lakshya
"""
n = 1
while (n < 10):
  print (n)
  n = n + 1

n = 1 
while ( True ):
  print (n)
  n = n + 1
  if ( n == 10 ) :
    break

n = 1
while (n < 10):
  if(n%2==0):
   print (n)
  n = n + 1

n = 1
while(True):
  if(n>10):
   break
  if(n%2==0):
   print (n)
  n = n + 1
  
n = 1
while (n < 10):
  if(n%2!=0):
   print (n)
  n = n + 1
  
n = 1
while(True):
  if(n>10):
   break
  if(n%2!=0):
   print (n)
  n = n + 1 