# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 21:34:43 2019

@author: Lakshya
"""
name=input("Enter a string>")
print(name)
"*".join(name)