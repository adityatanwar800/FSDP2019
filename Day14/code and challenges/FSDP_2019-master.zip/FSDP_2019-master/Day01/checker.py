# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 17:35:53 2019

@author: Lakshya
"""
print('* '*8)
print(' *'*8)
print('* '*8)
print(' *'*8)
print('* '*8)
print(' *'*8)
print('* '*8)
