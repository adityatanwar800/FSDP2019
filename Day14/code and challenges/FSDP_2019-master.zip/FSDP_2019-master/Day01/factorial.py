# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 18:14:00 2019

@author: Lakshya
"""
import math
print(math.factorial)
fact=int(input("Enter a number>"))
print("Factorial=" +str(math.factorial(fact)))
