# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 12:16:10 2019

@author: Lakshya
"""

from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup as BS

url="https://www.youtube.com/"

browser = webdriver.Chrome("C:/Users/Lakshya/Downloads/chromedriver_win32/chromedriver.exe")
browser.get(url)


sleep(2)

 
yt_search= browser.find_element_by_name("search_query")
search="nucleya"
yt_search.send_keys(search)

sleep(2)

enter = browser.find_element_by_xpath('//*[@id="search-icon-legacy"]')
enter.click()

sleep(2)

play = browser.find_element_by_xpath('//*[@id="button"]')
play.click()


