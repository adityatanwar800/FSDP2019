# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 16:28:50 2019

@author: Lakshya
"""

import urllib.request

urllib.request.urlretrieve("http://forsk.in/images/Forsk_logo_bw.png", "Forsk_logo_bw.png")
