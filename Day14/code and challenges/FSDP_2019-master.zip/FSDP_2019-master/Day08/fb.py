# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 22:46:54 2019

@author: Lakshya
"""

from  selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup as BS

#url = "http://keralaresults.nic.in/sslc2018rgr8364/swr_sslc.htm"
url = "https://www.facebook.com/"



browser = webdriver.Chrome("C:/Users/Lakshya/Downloads/chromedriver_win32/chromedriver.exe")
#browser = webdriver.Firefox(executable_path="D:/Forsk Technologies/geckodriver")
browser.get(url)


sleep(1)

 
email_id= browser.find_element_by_name("email")
email="lakshyamathur00@gmail.com"
email_id.send_keys(email)

sleep(1)

 
enter_pass= browser.find_element_by_name("pass")
password="jb"
enter_pass.send_keys(password)

sleep(2)


google_login = browser.find_element_by_xpath('//*[@id="loginbutton"]')
google_login.click()


sleep(2)

google_nav = browser.find_element_by_xpath('//*[@id="userNavigationLabel"]')
google_nav.click()

sleep(2)


google_logout = browser.find_element_by_xpath('//*[@id="js_17"]/div/div/ul/li[19]/a/span/span')
google_logout.click()

sleep(5)
 
html_page = browser.page_source

soup = BS(html_page)


sleep(3)


browser.quit()
//////////////////////////////////////////////////////////////////////



sleep(2)
fb_search= browser.find_element_by_name("q")
search="meha mathur"
fb_search.send_keys(search)

sleep(2)


google_search = browser.find_element_by_xpath('//*[@id="js_g9"]')
google_search.click()

sleep(2)


google_open = browser.find_element_by_xpath('//*[@id="xt_uniq_15"]/div/div/div[1]/div[1]/div[1]/a')
google_open.click()

sleep(2)


google_add = browser.find_element_by_xpath('//*[@id="u_ps_fetchstream_8_1_3"]/button[1]')
google_add.click()

sleep(3)


