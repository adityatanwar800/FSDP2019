# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 09:54:04 2019

@author: Lakshya
"""

from  selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup as BS

#url = "http://keralaresults.nic.in/sslc2018rgr8364/swr_sslc.htm"
url = "https://www.google.com/"



browser = webdriver.Chrome("C:/Users/Lakshya/Downloads/chromedriver_win32/chromedriver.exe")
#browser = webdriver.Firefox(executable_path="D:/Forsk Technologies/geckodriver")
browser.get(url)


sleep(2)

 
google_search= browser.find_element_by_name("q")
search="jaguar"
google_search.send_keys(search)

sleep(2)

enter = browser.find_element_by_xpath('//*[@id="tsf"]/div[2]/div/div[2]/div[2]/div/center/input[1]')
enter.click()

sleep(2)

site= browser.find_element_by_xpath('//*[@id="vn1s0p1c0"]/div/cite')
site.click()

sleep(2)
 
html_page = browser.page_source

soup = BS(html_page)


sleep(3)


browser.quit()